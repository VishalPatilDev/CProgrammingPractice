#include<stdio.h>
void main()
{
    int l=10,b=20;
    if(l,b>0){
        printf("Area of rectangle is : %d\n",l*b);
        printf("Peremeter of rectangle is : %d",(l+b)*2);

    }
    else{
        printf("Wrong input");
    }
}