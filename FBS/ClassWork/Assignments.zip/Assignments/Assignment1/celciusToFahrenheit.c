#include<stdio.h>  
                   void main()   
                   {   
                   float fahrenheit, celsius;  
                   celsius = 24;  
                   fahrenheit =( (celsius*9)/5)+32;  
                   printf("\n\n Temperature in fahrenheit is:  %f",fahrenheit);
    }  