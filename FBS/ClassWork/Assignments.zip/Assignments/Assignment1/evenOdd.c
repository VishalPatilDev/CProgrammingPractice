#include<stdio.h>
void main(){
    int num = 100;
    if(num%2==0){
        printf("%d is an even number\n",num);

    }
    else{
        printf("%d is an odd number",num);
    }
}