#include<stdio.h>
void main(){
    int num = 100;
    if(num>0){
        printf("Number is positive");
    }
    else if (num<0){
        printf("Number is negative");
    }
    else{
        printf("Number is neutral");
    }
}